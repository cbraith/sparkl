/** One rate-limit window as the engine reports it, kept for drawing. */
export type Window = { kind: string; percentUsed: number; resetsAt?: string }

/** The last reading the band drew from, and when it was taken (epoch ms). */
export type Reading = { windows: Window[]; at: number }

declare module 'claude-code' {
  interface PluginState {
    'usage-band': {
      /** Null until the first reading arrives. */
      reading: Reading | null
      /** Bumped once a minute so the "resets in" countdown redraws. */
      tick: number
      /** The person pressed Hide; the band stays away for this session. */
      isHidden: boolean
    }
  }
}
