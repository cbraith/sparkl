import { atom, read, update } from 'claude-code'
import type { Register } from 'claude-code'

import type { Reading, Window } from '../types'

// usage-band: a one-line band above the prompt with each rate-limit window
// the engine reports (5-hour, weekly, and any other kind that arrives), as a
// bar, a percentage and the time until it resets.
//
// Readings come pushed from `session.measure` (fired whenever a window moves
// a whole point), with one `$.session.usage()` call at start and on Refresh.

const reading = atom({ plugin: 'usage-band', key: 'reading' } as const, null)
const tick = atom({ plugin: 'usage-band', key: 'tick' } as const, 0)
const isHidden = atom({ plugin: 'usage-band', key: 'isHidden' } as const, false)

const BAR_CELLS = 10

/** A readable name for a window kind: the two known ones, else the kind itself humanized. */
function labelOf(kind: string): string {
  if (kind === 'five_hour') return '5-hour'
  if (kind === 'seven_day') return 'Weekly'
  if (kind === 'spend_limit') return 'Spend'
  return kind.replace(/[_-]+/g, ' ').replace(/^\w/, c => c.toUpperCase())
}

/** Sort known windows first (5-hour, weekly), anything else after in name order. */
function orderOf(kind: string): number {
  if (kind === 'five_hour') return 0
  if (kind === 'seven_day') return 1
  return 2
}

/** Green below 70%, yellow to 90%, red beyond. */
function colorOf(percent: number): string {
  if (percent >= 90) return 'red'
  if (percent >= 70) return 'yellow'
  return 'green'
}

/** `███░░░░░░░` for the percentage, BAR_CELLS wide. */
function barOf(percent: number): string {
  const filled = Math.max(0, Math.min(BAR_CELLS, Math.round((percent / 100) * BAR_CELLS)))
  return '█'.repeat(filled) + '░'.repeat(BAR_CELLS - filled)
}

/** "resets 2h 15m", "resets 3d 4h", "resets <1m", or '' when unknown. */
function resetText(resetsAt: string | undefined, now: number): string {
  if (!resetsAt) return ''
  const ms = Date.parse(resetsAt) - now
  if (Number.isNaN(ms)) return ''
  if (ms <= 0) return 'resetting'
  const minutes = Math.ceil(ms / 60_000)
  if (minutes < 1) return 'resets <1m'
  if (minutes < 60) return `resets ${minutes}m`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `resets ${hours}h ${minutes % 60}m`
  const days = Math.floor(hours / 24)
  return `resets ${days}d ${hours % 24}h`
}

/** The tool the model can call: `mcp__usage-band__usage`. */
const TOOL_NAME = 'usage'
const TOOL_FULL_NAME = 'mcp__usage-band__usage'

/** One line per window, for the tool's answer: "5-hour: 31% used, resets 2h 15m". */
function summarize(windows: readonly Window[], now: number): string {
  if (windows.length === 0) {
    return 'No rate-limit reading is available yet (nothing reported by the last response).'
  }
  const sorted = [...windows].sort((a, b) => orderOf(a.kind) - orderOf(b.kind) || a.kind.localeCompare(b.kind))
  return sorted
    .map(w => {
      const reset = resetText(w.resetsAt, now)
      return `${labelOf(w.kind)}: ${Math.round(w.percentUsed)}% used${reset ? `, ${reset}` : ''}`
    })
    .join('\n')
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    try {
      const usage = await $.session.usage()
      const now = await $.clock.now()
      await update($, reading, () => toReading(usage.rateLimits, now))
    } catch {
      // No reading yet (off a subscription, or before the first response): the band stays quiet.
    }

    // Once a minute, bump the tick so the "resets in" countdown redraws.
    $.clock.every(60_000, () => update($, tick, n => (n ?? 0) + 1))

    const started = await next(e)

    // A tool the model can call, so the person can ask for their usage in any
    // chat, including surfaces that draw no band.
    try {
      await $.tool.register({
        name: TOOL_NAME,
        description:
          "Report the account's Claude rate-limit windows (5-hour, weekly, and any others reported) as percent used and time until reset. Call it when the person asks about their usage, limits or quota. Takes no input.",
        inputSchema: { type: 'object', properties: {} },
      })
    } catch {
      // Registration refused (no bound session): the band still works.
    }

    return started
  })

  on('tool.call', { tool: TOOL_FULL_NAME }, async $ => {
    const usage = await $.session.usage()
    const now = await $.clock.now()
    await update($, reading, () => toReading(usage.rateLimits, now))

    return { result: summarize(usage.rateLimits, now) }
  })

  on('session.measure', async ($, e, next) => {
    if (e.changed.includes('rateLimits')) {
      const now = await $.clock.now()
      await update($, reading, () => toReading(e.rateLimits, now))
    }

    return next(e)
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const current = await read($, reading)
    const hidden = await read($, isHidden)
    await read($, tick) // subscribe to the minute tick

    if (e.props.hasSurvey || hidden || current === null || current.windows.length === 0) {
      return next(e)
    }

    const now = await $.clock.now()
    const { Box, Button, Text } = $.ui.resolve(e)
    const windows = [...current.windows].sort(
      (a, b) => orderOf(a.kind) - orderOf(b.kind) || a.kind.localeCompare(b.kind),
    )

    return (
      <Box flexDirection="row" gap={2}>
        <Text dimColor>Usage</Text>
        {windows.map(w => (
          <Box key={w.kind} flexDirection="row" gap={1}>
            <Text dimColor>{labelOf(w.kind)}</Text>
            <Text color={colorOf(w.percentUsed)}>{barOf(w.percentUsed)}</Text>
            <Text bold color={colorOf(w.percentUsed)}>
              {Math.round(w.percentUsed)}%
            </Text>
            <Text dimColor>{resetText(w.resetsAt, now)}</Text>
          </Box>
        ))}
        <Button
          key="refresh"
          label="Refresh"
          plain
          onPress={async () => {
            const usage = await $.session.usage()
            const at = await $.clock.now()
            await update($, reading, () => toReading(usage.rateLimits, at))
          }}
        />
        <Button key="hide" label="Hide" plain onPress={() => update($, isHidden, () => true)} />
      </Box>
    )
  })
}

function toReading(windows: readonly Window[], at: number): Reading {
  return {
    windows: windows.map(w => ({ kind: w.kind, percentUsed: w.percentUsed, resetsAt: w.resetsAt })),
    at,
  }
}
