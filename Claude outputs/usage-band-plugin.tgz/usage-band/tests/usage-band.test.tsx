import { expect, mock, test } from 'claude-code/testing'
import type { On, SessionRateLimit, SessionUsage } from 'claude-code'

const BAND = {
  plugin: 'usage-band',
  component: 'AbovePrompt',
  props: {
    hasSurvey: false,
    isWorking: false,
    maxRows: 10,
    bodyColumns: 160,
    scroll: { offset: 0, bodyRows: 10 },
    view: {},
  },
} as const

const context = { window: 200_000, tokens: 20_000, percent: 10 }

function usageOf(rateLimits: SessionRateLimit[]): SessionUsage {
  return { startedAt: 0, context, rateLimits }
}

/** Stand in for the engine beneath the plugin: a clock, an empty band, and the ops it calls. */
function engineBeneath(on: On, usage: () => SessionUsage) {
  mock.clock(on, { now: Date.now() })
  on('ui.render', () => ({ type: 'engine', ref: 0 }) as const) // core draws nothing of its own in the band
  on('session.usage', () => ({ value: usage() }))
  on('session.measure', (_$, e) => ({ changed: e.changed }))
  on('session.start', (_$, e) => ({ cwd: e.cwd }))
}

test('draws each window with its percent and reset time, on terminal and desktop', async ($, on) => {
  const inTwoHours = new Date(Date.now() + 2 * 60 * 60_000 + 10_000).toISOString()
  const windows: SessionRateLimit[] = [
    { kind: 'seven_day', percentUsed: 42.5, resetsAt: new Date(Date.now() + 3 * 86_400_000).toISOString() },
    { kind: 'five_hour', percentUsed: 91, resetsAt: inTwoHours },
  ]
  engineBeneath(on, () => usageOf(windows))

  // A measurement arrives, as the engine pushes one when a window moves.
  await $.session.measure({ context, rateLimits: windows, changed: ['rateLimits'] })

  for (const surface of ['terminal', 'desktop'] as const) {
    const ui = await $.ui.mount({ ...BAND, surface })

    // 5-hour sorts first, weekly second, each with its percent.
    const labels = (await ui.findAll({ type: 'Text', text: /^(5-hour|Weekly)$/ })).map(t => t.text)
    expect(labels).toEqual(['5-hour', 'Weekly'])
    expect(await ui.find({ type: 'Text', text: '91%' })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: '43%' })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: /resets 2h/ })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: /resets 3d/ })).toBeDefined()
    expect(await ui.find({ type: 'Button', key: 'refresh' })).toBeDefined()

    await ui.unmount()
  }
})

test('shows an unknown window kind under a humanized label', async ($, on) => {
  const windows: SessionRateLimit[] = [
    { kind: 'five_hour', percentUsed: 10 },
    { kind: 'seven_day_fable', percentUsed: 65 },
  ]
  engineBeneath(on, () => usageOf(windows))
  await $.session.measure({ context, rateLimits: windows, changed: ['rateLimits'] })

  const ui = await $.ui.mount({ ...BAND, surface: 'terminal' })
  expect(await ui.find({ type: 'Text', text: 'Seven day fable' })).toBeDefined()
  expect(await ui.find({ type: 'Text', text: '65%' })).toBeDefined()
  await ui.unmount()
})

test('stays quiet before any reading, and after Hide', async ($, on) => {
  const windows: SessionRateLimit[] = [{ kind: 'five_hour', percentUsed: 20 }]
  engineBeneath(on, () => usageOf(windows))

  // Nothing read yet: the hook passes, so the band holds no Text of ours.
  const empty = await $.ui.mount({ ...BAND, surface: 'terminal' })
  expect(await empty.find({ type: 'Text', text: 'Usage' })).toBeUndefined()
  await empty.unmount()

  await $.session.measure({ context, rateLimits: windows, changed: ['rateLimits'] })
  const ui = await $.ui.mount({ ...BAND, surface: 'terminal' })
  expect(await ui.find({ type: 'Text', text: 'Usage' })).toBeDefined()

  await ui.press({ key: 'hide' })
  expect(await ui.find({ type: 'Text', text: 'Usage' })).toBeUndefined()
  await ui.unmount()
})

test('Refresh re-reads the windows from the engine', async ($, on) => {
  let windows: SessionRateLimit[] = [{ kind: 'five_hour', percentUsed: 20 }]
  engineBeneath(on, () => usageOf(windows))

  await $.session.measure({ context, rateLimits: windows, changed: ['rateLimits'] })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  expect(await ui.find({ type: 'Text', text: '20%' })).toBeDefined()

  windows = [{ kind: 'five_hour', percentUsed: 55 }]
  await ui.press({ key: 'refresh' })
  expect(await ui.find({ type: 'Text', text: '55%' })).toBeDefined()
  expect(await ui.find({ type: 'Text', text: '20%' })).toBeUndefined()
  await ui.unmount()
})

test('registers a usage tool at session start and answers it with one line per window', async ($, on) => {
  const windows: SessionRateLimit[] = [
    { kind: 'seven_day', percentUsed: 58.2, resetsAt: new Date(Date.now() + 3 * 86_400_000 + 4 * 3_600_000 + 60_000).toISOString() },
    { kind: 'five_hour', percentUsed: 31, resetsAt: new Date(Date.now() + 2 * 3_600_000 + 15 * 60_000 + 10_000).toISOString() },
  ]
  engineBeneath(on, () => usageOf(windows))
  const registered: string[] = []
  on('tool.register', (_$, e) => {
    registered.push(e.name)
    return { value: { tool: `mcp__usage-band__${e.name}` } }
  })

  await $.session.start({ cwd: '/tmp', surface: 'desktop', isInteractive: true })
  expect(registered).toEqual(['usage'])

  const answer = await $.tool.call({ tool: 'mcp__usage-band__usage' })
  expect(answer.deny).toBeUndefined()
  expect(answer.result).toMatch(/^5-hour: 31% used, resets 2h 1[56]m\nWeekly: 58% used, resets 3d 4h$/)
})
